//
//  Constants.swift
//  OAuthSwift
//
//  Created by Dongri Jin on 7/17/14.
//  Copyright (c) 2014 Dongri Jin. All rights reserved.
//

import Foundation

let Twitter =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Salesforce =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Flickr =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Github =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Instagram =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Foursquare =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Fitbit =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Withings =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Linkedin =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Linkedin2 =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Dropbox =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Dribbble =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let BitBucket =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let GoogleDrive =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Smugmug =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Intuit =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Zaim =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Tumblr =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Slack =
[
    "consumerKey": "",
    "consumerSecret": ""
]
let Uber =
[
    "consumerKey": "",
    "consumerSecret": ""
]
