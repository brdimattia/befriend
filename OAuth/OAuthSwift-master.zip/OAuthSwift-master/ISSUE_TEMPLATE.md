 == Describe here the steps to reproduce, with error message if any, and your code if relevant ==

- **OS targeted (with version):** ??
- **OAuth provider:** ??
- **OAuthSwift version:** previous/last release, master head???
